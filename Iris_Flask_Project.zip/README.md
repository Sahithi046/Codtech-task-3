
# Iris Flower Prediction API 🌸

This is a simple Flask API for predicting the species of iris flowers based on sepal and petal measurements using a trained Random Forest model.

## 🚀 How to Run Locally

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Run the app:
```
python app.py
```

3. Use `/predict` endpoint with JSON input like:
```json
{
  "features": [5.1, 3.5, 1.4, 0.2]
}
```

## 📁 Files Included
- `app.py`: Flask API
- `iris_model.pkl`: Trained model file
- `requirements.txt`: Dependencies
